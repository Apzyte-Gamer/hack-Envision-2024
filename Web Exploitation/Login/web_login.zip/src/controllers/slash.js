export function homeRouterHandler(req,res){
    res.render("home.ejs")
}