#!/bin/bash

/usr/bin/docker rmi --force time_trial:latest

/usr/bin/docker build -t  time_trial:latest .

/usr/bin/docker run -p 0.0.0.0:1337:1337  time_trial:latest
